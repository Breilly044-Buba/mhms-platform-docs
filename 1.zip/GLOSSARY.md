# Glossary

## AI
Artificial Intelligence
