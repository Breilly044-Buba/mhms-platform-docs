# MHMS Legal Lead Intelligence Platform

See docs folder for full documentation.
